package drivehq;

public class Test {

	public static void main(String[] args) {
		
		//FileUpload.fileUpload("D:\\1.txt");
		
		FileDownload.fileDownload("D:\\appdownloads\\1.txt");
	}
}
